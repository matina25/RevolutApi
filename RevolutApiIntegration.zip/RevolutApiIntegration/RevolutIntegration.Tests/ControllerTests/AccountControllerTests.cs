﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using RevolutIntegration.Api.Controllers;
using RevolutIntegration.Application.ModelsDto;
using RevolutIntegration.Application.Queries;

namespace RevolutIntegration.Tests.ControllerTests
{
    public class AccountControllerTests
    {
            private readonly Mock<IMediator> _mediatorMock;
            private readonly AccountController _controller;

            public AccountControllerTests()
            {
                // Arrange: Set up the mediator mock
                _mediatorMock = new Mock<IMediator>();

                // Initialize the controller with the mocked mediator
                _controller = new AccountController(_mediatorMock.Object);
            }

            [Fact]
            public async Task GetAccountsAsync_ReturnsOkResult_WithListOfAccounts()
            {
                var mockAccounts = new List<AccountDto>
            {
                new AccountDto { AccountId = 1, Balance = 1000, Currency = "USD", AccountType = "Checking" },
                new AccountDto { AccountId = 2, Balance = 2000, Currency = "EUR", AccountType = "Savings" }
            };

                _mediatorMock.Setup(m => m.Send(It.IsAny<GetAllAccountsQuery>(), It.IsAny<CancellationToken>()))
                             .ReturnsAsync(mockAccounts);

                var result = await _controller.GetAccountsAsync();

                var okResult = Assert.IsType<OkObjectResult>(result);
                Assert.Equal(200, okResult.StatusCode);

                var returnedAccounts = Assert.IsType<List<AccountDto>>(okResult.Value);
                Assert.Equal(mockAccounts.Count, returnedAccounts.Count); 
            }

        [Fact]
        public async Task GetAccountsAsync_ReturnsOkResult_WithEmptyList_WhenNoAccounts()
        {
            var mockAccounts = new List<AccountDto>();

            _mediatorMock.Setup(m => m.Send(It.IsAny<GetAllAccountsQuery>(), It.IsAny<CancellationToken>()))
                         .ReturnsAsync(mockAccounts);

            var result = await _controller.GetAccountsAsync();

            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, okResult.StatusCode);

            var returnedAccounts = Assert.IsType<List<AccountDto>>(okResult.Value);
            Assert.Empty(returnedAccounts); 
        }
    }
    }
