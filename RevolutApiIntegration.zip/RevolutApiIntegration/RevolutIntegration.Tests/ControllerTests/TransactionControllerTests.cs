﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using RevolutIntegration.Api.Controllers;
using RevolutIntegration.Application.ModelsDto;
using RevolutIntegration.Application.Queries;

namespace RevolutIntegration.Tests.ControllerTests
{
    public class TransactionControllerTests
    {
        private readonly Mock<IMediator> _mediatorMock;
        private readonly TransactionController _controller;

        public TransactionControllerTests()
        {
            // Arrange: Set up the mediator mock
            _mediatorMock = new Mock<IMediator>();

            // Initialize the controller with the mocked mediator
            _controller = new TransactionController(_mediatorMock.Object);
        }

        [Fact]
        public async Task GetAllTransactionsByAccount_ReturnsOkResult_WithListOfTransactions()
        {
            int accountId = 1;
            var mockTransactions = new List<TransactionDto>
            {
                new TransactionDto { TransactionId = "T1", Amount = 100, Currency = "USD" },
                new TransactionDto { TransactionId = "T2", Amount = 200, Currency = "EUR" }
            };

            _mediatorMock.Setup(m => m.Send(It.Is<GetAllTransactionsByAccountQuery>(q => q.AccountId == accountId), It.IsAny<CancellationToken>()))
                         .ReturnsAsync(mockTransactions);

            var result = await _controller.GetAllTransactionsByAccount(accountId);

            var okResult = Assert.IsType<OkObjectResult>(result.Result);
            Assert.Equal(200, okResult.StatusCode);

            var returnedTransactions = Assert.IsType<List<TransactionDto>>(okResult.Value);
            Assert.Equal(mockTransactions.Count, returnedTransactions.Count);
        }
    }
}
