﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using RevolutIntegration.Api.Controllers;
using RevolutIntegration.Application.Commands;
using RevolutIntegration.Application.ModelsDto;

namespace RevolutIntegration.Tests.ControllerTests
{
    public class InitiatePaymentControllerTests
    {

        private readonly Mock<IMediator> _mediatorMock;
        private readonly InitiatePaymentController _controller;

        public InitiatePaymentControllerTests()
        {
            _mediatorMock = new Mock<IMediator>();
            _controller = new InitiatePaymentController(_mediatorMock.Object);
        }

        [Fact]
        public async Task InitiatePayment_ShouldReturnOk_WhenPaymentIsSuccessful()
        {
            // Arrange
            var paymentDto = new PaymentDto
            {
                Amount = 100,
                Currency = "USD",
                RecipientAccountId = "receiver-id"
            };

            _mediatorMock.Setup(m => m.Send(It.IsAny<InitiatePaymentCommand>(), It.IsAny<CancellationToken>()))
                         .ReturnsAsync(true);

            // Act
            var result = await _controller.InitiatePayment(paymentDto);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("Payment initiated successfully.", okResult.Value);

            _mediatorMock.Verify(m => m.Send(It.Is<InitiatePaymentCommand>(cmd =>
                cmd.Payment == paymentDto), It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task InitiatePayment_ShouldReturnStatusCode500_WhenPaymentFails()
        {
            // Arrange
            var paymentDto = new PaymentDto
            {
                Amount = 100,
                Currency = "USD",
                RecipientAccountId = "receiver-id"
            };

            _mediatorMock.Setup(m => m.Send(It.IsAny<InitiatePaymentCommand>(), It.IsAny<CancellationToken>()))
                         .ReturnsAsync(false);

            // Act
            var result = await _controller.InitiatePayment(paymentDto);

            // Assert
            var statusCodeResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, statusCodeResult.StatusCode);
            Assert.Equal("Failed to initiate payment.", statusCodeResult.Value);

            _mediatorMock.Verify(m => m.Send(It.Is<InitiatePaymentCommand>(cmd =>
                cmd.Payment == paymentDto), It.IsAny<CancellationToken>()), Times.Once);
        }

    }
}
