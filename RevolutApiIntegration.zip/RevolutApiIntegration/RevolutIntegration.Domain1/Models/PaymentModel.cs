﻿namespace RevolutIntegration.Domain.Models
{
    public class PaymentModel
    {
        public decimal Amount { get; set; }
        public string Currency { get; set; }
        public string RecipientAccountId { get; set; }
    }
}
