﻿using AutoMapper;
using RevolutIntegration.Domain.Models;
using RevolutIntegration.Infrastructure.Models;

namespace RevolutIntegration.Domain.Mapping
{
    public class ProfileMapping : Profile
    {
        public ProfileMapping() 
        {
            CreateMap<AccountModel, Account>().ReverseMap();

            CreateMap<TransactionModel, Transaction>().ReverseMap();

            CreateMap<PaymentModel, Payment>().ReverseMap();
        }
    }
}
