﻿using Microsoft.Extensions.Logging;
using RevolutIntegration.Domain.Models;
using RevolutIntegration.Infrastructure.Services;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace RevolutIntegration.Domain.Services
{
    public interface IPaymentService
    {
        Task<bool> InitiatePaymentAsync(PaymentModel payment);
    }

    public class PaymentService : IPaymentService
    {
        private readonly IOAuthService _authService;
        private readonly HttpClient _httpClient;
        private readonly ILogger<PaymentService> _logger;

        public PaymentService(IOAuthService authService, HttpClient httpClient, ILogger<PaymentService> logger)
        {
            _authService = authService;
            _httpClient = httpClient;
            _logger = logger;
        }

        public async Task<bool> InitiatePaymentAsync(PaymentModel payment)
        {
            try
            {
                _logger.LogInformation("Initiating payment for amount: {Amount} to account: {RecipientAccountId}", payment.Amount, payment.RecipientAccountId);

                var token = await _authService.GetAccessTokenAsync();
                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var content = new StringContent(JsonSerializer.Serialize(payment), Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync("https://sandbox-b2b.revolut.com/api/1.0/payment", content);

                if (response.IsSuccessStatusCode)
                {
                    _logger.LogInformation("Payment successfully initiated for account: {RecipientAccountId}", payment.RecipientAccountId);
                    return true;
                }
                else
                {
                    _logger.LogWarning("Failed to initiate payment for account: {RecipientAccountId}. Status Code: {StatusCode}", payment.RecipientAccountId, response.StatusCode);
                    return false;
                }
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "An HTTP error occurred while initiating payment for account: {RecipientAccountId}", payment.RecipientAccountId);
                throw new ApplicationException("An error occurred while initiating payment.", ex);
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, "An error occurred while serializing payment data for account: {RecipientAccountId}", payment.RecipientAccountId);
                throw new ApplicationException("Failed to serialize payment data.", ex);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An unexpected error occurred while initiating payment for account: {RecipientAccountId}", payment.RecipientAccountId);
                throw new ApplicationException("An unexpected error occurred while initiating payment.", ex);
            }
        }
    }
}
