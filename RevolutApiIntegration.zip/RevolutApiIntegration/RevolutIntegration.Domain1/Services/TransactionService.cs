﻿using Microsoft.Extensions.Logging;
using RevolutIntegration.Domain.Models;
using RevolutIntegration.Infrastructure.Services;
using System.Net.Http.Headers;
using System.Text.Json;

namespace RevolutIntegration.Domain.Services
{
    public interface ITransactionService
    {
        Task<List<TransactionModel>> GetTransactionsAsync(int accountId);
    }

    public class TransactionService : ITransactionService
    {
        private readonly IOAuthService _authService;
        private readonly HttpClient _httpClient;
        private readonly ILogger<TransactionService> _logger;

        public TransactionService(IOAuthService authService, HttpClient httpClient, ILogger<TransactionService> logger)
        {
            _authService = authService;
            _httpClient = httpClient;
            _logger = logger;
        }

        public async Task<List<TransactionModel>> GetTransactionsAsync(int accountId)
        {
            try
            {
                _logger.LogInformation("Retrieving transactions for accountId: {AccountId}", accountId);

                var token = await _authService.GetAccessTokenAsync();
                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.GetAsync($"https://sandbox-b2b.revolut.com/api/1.0/transaction/{accountId}/transactions");

                if (response.IsSuccessStatusCode)
                {
                    _logger.LogInformation("Successfully retrieved transactions for accountId: {AccountId}", accountId);

                    var content = await response.Content.ReadAsStringAsync();
                    var transactions = JsonSerializer.Deserialize<List<TransactionModel>>(content);

                    return transactions;
                }
                else
                {
                    _logger.LogWarning("Failed to retrieve transactions for accountId: {AccountId}. Status Code: {StatusCode}", accountId, response.StatusCode);
                    return new List<TransactionModel>(); 
                }
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "An HTTP error occurred while retrieving transactions for accountId: {AccountId}", accountId);
                throw new ApplicationException("An error occurred while retrieving transactions.", ex);
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, "An error occurred while deserializing transactions for accountId: {AccountId}", accountId);
                throw new ApplicationException("Failed to deserialize transaction data.", ex);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An unexpected error occurred while retrieving transactions for accountId: {AccountId}", accountId);
                throw new ApplicationException("An unexpected error occurred while retrieving transactions.", ex);
            }
        }
    }
}
