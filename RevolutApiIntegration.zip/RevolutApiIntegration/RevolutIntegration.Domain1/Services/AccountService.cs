﻿using Microsoft.Extensions.Logging;
using RevolutIntegration.Domain.Models;
using RevolutIntegration.Infrastructure.Services;
using System.Net.Http.Headers;
using System.Text.Json;

namespace RevolutIntegration.Domain.Services
{
    public interface IAccountService
    {
        Task<List<AccountModel>> GetAccountsAsync();
    }

    public class AccountService : IAccountService
    {
        private readonly IOAuthService _authService;
        private readonly HttpClient _client;
        private readonly ILogger<AccountService> _logger;

        public AccountService(IOAuthService oAuthService, HttpClient httpClient, ILogger<AccountService> logger)
        {
            _client = httpClient;
            _authService = oAuthService;
            _logger = logger;
        }

        public async Task<List<AccountModel>> GetAccountsAsync()
        {
            try
            {
                _logger.LogInformation("Fetching accounts...");

                var token = await _authService.GetAccessTokenAsync();
                _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _client.GetAsync("https://sandbox-b2b.revolut.com/accounts");

                response.EnsureSuccessStatusCode();

                var content = await response.Content.ReadAsStringAsync();
                var accounts = JsonSerializer.Deserialize<List<AccountModel>>(content);

                _logger.LogInformation("Successfully fetched {AccountCount} accounts.", accounts?.Count ?? 0);

                return accounts;
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "An HTTP error occurred while fetching accounts.");
                throw new ApplicationException("An error occurred while fetching accounts from Revolut API.", ex);
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, "An error occurred while deserializing the account data.");
                throw new ApplicationException("Failed to deserialize the account data.", ex);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An unexpected error occurred while fetching accounts.");
                throw new ApplicationException("An unexpected error occurred while fetching accounts.", ex);
            }
        }
    }
}
