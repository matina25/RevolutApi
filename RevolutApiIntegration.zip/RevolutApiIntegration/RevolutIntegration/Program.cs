using MediatR;
using RevolutIntegration.Application.Commands;
using RevolutIntegration.Application.Queries;
using RevolutIntegration.Domain.Mapping;
using RevolutIntegration.Domain.Services;
using RevolutIntegration.Infrastructure.Services;

namespace RevolutIntegration
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddSingleton<IConfiguration>(builder.Configuration);
            builder.Services.AddTransient<IOAuthService, OAuthService>();
            builder.Services.AddHttpClient<IAccountService, AccountService>();
            builder.Services.AddMediatR(typeof(GetAllAccountsQuery).Assembly);
            builder.Services.AddAutoMapper(typeof(ProfileMapping).Assembly);
            builder.Services.AddScoped<ITransactionService, TransactionService>();
            builder.Services.AddMediatR(typeof(InitiatePaymentCommandHandler).Assembly);
            builder.Services.AddScoped<IPaymentService, PaymentService>();
            builder.Services.AddHttpClient<IPaymentService, PaymentService>();
            builder.Services.AddLogging(logging =>
            {
                logging.ClearProviders();
            });

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
