﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using RevolutIntegration.Application.Commands;
using RevolutIntegration.Application.ModelsDto;

namespace RevolutIntegration.Api.Controllers
{
    [ApiController]
    [Route("api/payments")]
    public class InitiatePaymentController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<InitiatePaymentController> _logger;

        public InitiatePaymentController(IMediator mediator, ILogger<InitiatePaymentController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        /// <summary>
        /// Initiates a payment.
        /// </summary>
        /// <param name="paymentDto">The payment details to be initiated.</param>
        /// <returns>Success or failure message based on payment initiation result.</returns>
        [HttpPost]
        public async Task<IActionResult> InitiatePayment([FromBody] PaymentDto paymentDto)
        {
            try
            {
                _logger.LogInformation("Initiating payment for account: {RecipientAccountId}", paymentDto.RecipientAccountId);

                var command = new InitiatePaymentCommand(paymentDto);
                bool result = await _mediator.Send(command);

                if (result)
                {
                    _logger.LogInformation("Payment initiated successfully for account: {RecipientAccountId}", paymentDto.RecipientAccountId);
                    return Ok("Payment initiated successfully.");
                }
                else
                {
                    _logger.LogWarning("Failed to initiate payment for account: {RecipientAccountId}", paymentDto.RecipientAccountId);
                    return StatusCode(500, "Failed to initiate payment.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while initiating payment for account: {RecipientAccountId}", paymentDto.RecipientAccountId);

                return StatusCode(500, "An error occurred while processing your request.");
            }
        }
    }
}
