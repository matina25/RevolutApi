﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using RevolutIntegration.Application.Queries;

namespace RevolutIntegration.Api.Controllers
{
    [ApiController]
    [Route("api/accounts")]
    public class AccountController : Controller
    {
        private readonly IMediator _mediator;
        private readonly ILogger<AccountController> _logger;

        public AccountController(IMediator mediator, ILogger<AccountController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        /// <summary>
        /// Retrieves a list of all accounts.
        /// </summary>
        /// <returns>List of accounts with details like balance, currency, and account type.</returns>
        [HttpGet]
        public async Task<IActionResult> GetAccountsAsync()
        {
            try
            {
                _logger.LogInformation("Getting all accounts.");

                var query = new GetAllAccountsQuery();
                var result = await _mediator.Send(query);

                _logger.LogInformation("Successfully retrieved accounts.");

                return Ok(result);  
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving accounts.");

                return StatusCode(500, "An error occurred while processing your request.");
            }
        }
    }
}
