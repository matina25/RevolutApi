﻿using Microsoft.AspNetCore.Mvc;
using RevolutIntegration.Domain.Services;
using RevolutIntegration.Infrastructure.Services;

namespace RevolutIntegration.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : Controller
    {
        private readonly IOAuthService _oAuthService;
        private readonly ILogger<AuthenticationController> _logger;

        public AuthenticationController(IOAuthService oAuthService, ILogger<AuthenticationController> logger)
        {
            _oAuthService = oAuthService;
            _logger = logger;
        }

        [HttpPost("token")]
        public async Task<IActionResult> GetAccessToken()
        {
            try
            {
                var accessToken = await _oAuthService.GetAccessTokenAsync();
                if (string.IsNullOrEmpty(accessToken))
                {
                    return Unauthorized("Failed to obtain access token.");
                }

                // Return the access token as a JSON response
                return Ok(new { access_token = accessToken });
            }
            catch (Exception ex)
            {
                _logger.LogError("Error obtaining access token: {Message}", ex.Message);
                return StatusCode(500, "Internal Server Error");
            }
        }
    }
}
