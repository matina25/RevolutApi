﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using RevolutIntegration.Application.ModelsDto;
using RevolutIntegration.Application.Queries;

namespace RevolutIntegration.Api.Controllers
{
    [ApiController]
    [Route("api/transactions")]
    public class TransactionController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<TransactionController> _logger;

        public TransactionController(IMediator mediator, ILogger<TransactionController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        /// <summary>
        /// Retrieves a list of all transactions by accountId.
        /// </summary>
        [HttpGet("{accountId}")]
        public async Task<ActionResult<List<TransactionDto>>> GetAllTransactionsByAccount(int accountId)
        {
            try
            {
                _logger.LogInformation("Fetching transactions for account ID: {AccountId}", accountId);

                var query = new GetAllTransactionsByAccountQuery { AccountId = accountId };
                var result = await _mediator.Send(query);

                if (result != null && result.Count > 0)
                {
                    _logger.LogInformation("Successfully retrieved transactions for account ID: {AccountId}", accountId);
                    return Ok(result);  
                }
                else
                {
                    _logger.LogWarning("No transactions found for account ID: {AccountId}", accountId);
                    return NotFound("No transactions found for the provided account ID.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while fetching transactions for account ID: {AccountId}", accountId);

                return StatusCode(500, "An error occurred while processing your request.");
            }
        }
    }
}
