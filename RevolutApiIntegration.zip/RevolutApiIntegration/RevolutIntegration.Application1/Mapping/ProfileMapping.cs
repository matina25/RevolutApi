﻿using AutoMapper;
using RevolutIntegration.Application.ModelsDto;
using RevolutIntegration.Domain.Models;

namespace RevolutIntegration.Application.Mapping
{
    public class AccountMappingDomain : Profile
    {
        public AccountMappingDomain()
        {
            CreateMap<AccountDto, AccountModel>().ReverseMap();
            CreateMap<TransactionDto, TransactionModel>().ReverseMap();
            CreateMap<PaymentDto, PaymentModel>().ReverseMap();
        }
    }
}
