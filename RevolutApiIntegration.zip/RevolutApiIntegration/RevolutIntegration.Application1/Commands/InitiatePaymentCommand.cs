﻿using AutoMapper;
using MediatR;
using RevolutIntegration.Application.ModelsDto;
using RevolutIntegration.Domain.Models;
using RevolutIntegration.Domain.Services;

namespace RevolutIntegration.Application.Commands
{
    public class InitiatePaymentCommand : IRequest<bool>
    {
        public PaymentDto Payment { get; }

        public InitiatePaymentCommand(PaymentDto payment)
        {
            Payment = payment;
        }
    }

    public class InitiatePaymentCommandHandler : IRequestHandler<InitiatePaymentCommand, bool>
    {
        private readonly IPaymentService _paymentService;
        private readonly IMapper _mapper;

        public InitiatePaymentCommandHandler(IPaymentService paymentService, IMapper mapper)
        {
            _paymentService = paymentService;
            _mapper = mapper;
        }

        public async Task<bool> Handle(InitiatePaymentCommand request, CancellationToken cancellationToken)
        {
            var paymentModel = _mapper.Map<PaymentModel>(request.Payment);

            return await _paymentService.InitiatePaymentAsync(paymentModel);
        }
    }
}
