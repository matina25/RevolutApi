﻿using AutoMapper;
using MediatR;
using RevolutIntegration.Application.ModelsDto;
using RevolutIntegration.Domain.Services;

namespace RevolutIntegration.Application.Queries
{
    public class GetAllAccountsQuery : IRequest<List<AccountDto>>
    {
    }

    public class GetAccountsQueryHandler : IRequestHandler<GetAllAccountsQuery, List<AccountDto>>
    {
        private readonly IAccountService _accountService;
        private readonly IMapper _mapper;

        public GetAccountsQueryHandler(IAccountService accountService, IMapper mapper)
        {
            _accountService = accountService;
            _mapper = mapper;
        }

        public async Task<List<AccountDto>> Handle(GetAllAccountsQuery request, CancellationToken cancellationToken)
        {
            var accounts = await _accountService.GetAccountsAsync();
            var accountDtos = _mapper.Map<List<AccountDto>>(accounts);

            return accountDtos;
        }
    }
}
