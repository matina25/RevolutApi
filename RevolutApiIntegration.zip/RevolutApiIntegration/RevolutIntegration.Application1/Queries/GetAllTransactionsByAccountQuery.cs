﻿using AutoMapper;
using MediatR;
using RevolutIntegration.Application.ModelsDto;
using RevolutIntegration.Domain.Services;

namespace RevolutIntegration.Application.Queries
{
    public class GetAllTransactionsByAccountQuery : IRequest<List<TransactionDto>>
    {
        public int AccountId { get; set; }
    }

    public class GetAllTransactionsByAccountQueryHandler : IRequestHandler<GetAllTransactionsByAccountQuery, List<TransactionDto>>
    {
        private readonly ITransactionService _transactionService;
        private readonly IMapper _mapper;

        public GetAllTransactionsByAccountQueryHandler(ITransactionService transactionService, IMapper mapper)
        {
            _transactionService = transactionService;
            _mapper = mapper;
        }

        public async Task<List<TransactionDto>> Handle(GetAllTransactionsByAccountQuery request, CancellationToken cancellationToken)
        {
            var transactions = await _transactionService.GetTransactionsAsync(request.AccountId);
            var transactionDtos = _mapper.Map<List<TransactionDto>>(transactions);

            return transactionDtos;
        }
    }
}
