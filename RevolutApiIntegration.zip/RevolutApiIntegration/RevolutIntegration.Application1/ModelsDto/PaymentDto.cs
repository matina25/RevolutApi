﻿namespace RevolutIntegration.Application.ModelsDto
{
    public class PaymentDto
    {
        public decimal Amount { get; set; }
        public string Currency { get; set; }
        public string RecipientAccountId { get; set; }
    }
}
