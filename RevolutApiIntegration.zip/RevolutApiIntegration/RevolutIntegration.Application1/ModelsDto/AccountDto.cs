﻿namespace RevolutIntegration.Application.ModelsDto
{
    public class AccountDto
    {
        public int AccountId { get; set; }
        public decimal Balance { get; set; }
        public string Currency { get; set; }
        public string IBAN { get; set; }
        public string AccountType { get; set; }
        public string AccountOwnerName { get; set; }
    }
}
