﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;

namespace RevolutIntegration.Domain.JWT
{
    public class JWT
    {
        public static string GenerateJwt(string kid, string clientId, string redirectUri, string consentId, string privateKeyPath)
        {
            var securityKey = new ECDsaSecurityKey(ECDsa.Create())
            {
                KeyId = kid
            };

            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.EcdsaSha256);

            var claims = new List<Claim>
        {
            new Claim("client_id", clientId),
            new Claim("redirect_uri", redirectUri),
            new Claim("response_type", "code id_token"),
            new Claim("scope", "accounts"),
            new Claim("state", Guid.NewGuid().ToString()),
            new Claim("openbanking_intent_id", consentId)
        };

            var jwtHeader = new JwtHeader(credentials);
            jwtHeader["alg"] = "PS256";
            jwtHeader["kid"] = kid;

            var jwtPayload = new JwtPayload(claims);
            var jwtToken = new JwtSecurityToken(jwtHeader, jwtPayload);

            var handler = new JwtSecurityTokenHandler();
            return handler.WriteToken(jwtToken);
        }
    }
}
