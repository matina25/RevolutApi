﻿namespace RevolutIntegration.Infrastructure.Models
{
    public class Payment
    {
        public decimal Amount { get; set; }
        public string Currency { get; set; }
        public string RecipientAccountId { get; set; }
    }
}
