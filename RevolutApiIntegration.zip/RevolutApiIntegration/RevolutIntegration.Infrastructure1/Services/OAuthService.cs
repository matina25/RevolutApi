﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using RevolutIntegration.Domain.JWT;
using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;

namespace RevolutIntegration.Infrastructure.Services
{
    public interface IOAuthService
    {
        public Task<string> GetAccessTokenAsync();
        public Task<string> ExchangeAuthCodeForTokenAsync(string code);
    }

    public class OAuthService : IOAuthService
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;
        private string _authCode;
        private string _accessToken;
        private DateTime _tokenExpiration;

        public OAuthService(HttpClient httpClient, IConfiguration configuration)
        {
            _configuration = configuration;
            _httpClient = httpClient;
        }

        public async Task<string> GetAccessTokenAsync()
        {
            // Check if token is valid and not expired
            if (!string.IsNullOrEmpty(_accessToken) && _tokenExpiration > DateTime.UtcNow)
            {
                return _accessToken;
            }

            // Token expired or not set; request a new token
            var clientId = _configuration["RevolutApi:ClientId"];
            var certificatePath = _configuration["RevolutApi:CertificatePath"];  // Path to your certificate
            var privateKeyPath = _configuration["RevolutApi:privateKeyPath"];
            var tokenUrl = _configuration["RevolutApi:TokenEndpoint"];

            var certificatePassword = _configuration["RevolutApi:CertificatePassword"];
            var certificate = new X509Certificate2(certificatePath, certificatePassword);
            var handler = new HttpClientHandler();
            handler.ClientCertificateOptions = ClientCertificateOption.Manual;
            handler.ClientCertificates.Add(certificate);
            handler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true;
            var client = new HttpClient(handler);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var request = new HttpRequestMessage(HttpMethod.Post, tokenUrl);
            request.Content = new FormUrlEncodedContent(
                new[] { new KeyValuePair<string, string>("grant_type", "client_credentials"),
            new KeyValuePair<string, string>("scope", "accounts"),
                new KeyValuePair<string, string>("client_id", clientId)});
            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();
            var content = await response.Content.ReadAsStringAsync();
            var tokenObject = JObject.Parse(content);
            var accessToken = tokenObject["access_token"].ToString();
            //await ExchangeAuthCodeForAccessTokenAsync(_authCode);
            await CreateConsentAndGetConsentIdAsync(accessToken);

            return accessToken;
        }
        public async Task<string> CreateConsentAndGetConsentIdAsync(string accessToken)
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "https://sandbox-oba.revolut.com/account-access-consents");

            request.Headers.Add("x-fapi-financial-id", "001580000103UAvAAM");
            request.Headers.Add("Authorization", $"Bearer {accessToken}");

            var jsonBody = @"{
            ""Data"": {
                ""Permissions"": [
                    ""ReadAccountsBasic"",
                    ""ReadAccountsDetail""
                ],
                ""ExpirationDateTime"": ""2020-12-02T00:00:00+00:00"",
                ""TransactionFromDateTime"": ""2020-09-03T00:00:00+00:00"",
                ""TransactionToDateTime"": ""2020-12-03T00:00:00+00:00""
            },
            ""Risk"": {}
        }";

            request.Content = new StringContent(jsonBody, Encoding.UTF8, "application/json");

            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();

            // Read and parse the response JSON to extract ConsentId
            var responseBody = await response.Content.ReadAsStringAsync();
            var responseJson = JsonDocument.Parse(responseBody);

            // Extract the ConsentId from the JSON response
            var consentId = responseJson.RootElement.GetProperty("Data").GetProperty("ConsentId").GetString();
            await GetAuthCodeUrlAsync(consentId);
            Console.WriteLine("ConsentId: " + consentId);

            return consentId;
        }

        public async Task<string> GetAuthCodeUrlAsync(string consentId)
        {
            var clientId = _configuration["RevolutApi:ClientId"];
            var privateKeyPath = _configuration["RevolutApi:privateKeyPath"];
            var jwtRequest = JWT.GenerateJwt("test", clientId, "https://google.com", consentId, privateKeyPath);

            var authorizationUrl = $"https://sandbox-oba.revolut.com/ui/index.html?response_type=code%20id_token&scope=accounts&redirect_uri={Uri.EscapeDataString("https://your-redirect-uri.com")}&client_id={Uri.EscapeDataString(clientId)}&request={Uri.EscapeDataString(jwtRequest)}";

            return authorizationUrl;
        }

        public async Task<string> ExchangeAuthCodeForTokenAsync(string code)
        {
            var clientId = _configuration["RevolutApi:ClientId"];
            var redirectUri = "https://your-redirect-uri.com";

            // Construct the request body
            var requestBody = new Dictionary<string, string>
        {
            { "grant_type", "authorization_code" },
            { "code", code },
            { "redirect_uri", redirectUri },
            { "client_id", clientId },
        };

            using var client = new HttpClient();
            var response = await client.PostAsync("https://sandbox-oba.revolut.com/oauth/token", new FormUrlEncodedContent(requestBody));

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return content;
            }
            return null;
        }

    }
}